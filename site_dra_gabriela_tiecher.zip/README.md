# Site — Dra. Gabriela Tiecher

## Arquivos
- `index.html`: estrutura e conteúdo da página.
- `styles.css`: identidade visual, layout responsivo e estilos.
- `script.js`: menu mobile e ano automático do rodapé.
- `assets/gabriela-portrait.jpg`: recorte da fotografia enviada como referência.

## Como usar no GitHub
1. Extraia o ZIP.
2. Envie todos os arquivos e a pasta `assets` para a raiz do repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**, escolha `main` e `/ (root)`.
5. Salve. O GitHub Pages publicará o `index.html`.

## Antes de publicar
Confirme com a profissional os procedimentos efetivamente oferecidos, horários de atendimento e textos institucionais. Os links de WhatsApp usam o telefone que aparece nas referências enviadas.
